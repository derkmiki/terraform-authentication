'use strict';

exports.handler = async function (event) {
    console.log(event);
    return event;
}